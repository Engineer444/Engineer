# print(11//2)
# x = 5
# y = 12
# print(5 % 4) # remainder
# print("hello \t world")
print ("hello \r world")
